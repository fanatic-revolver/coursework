%{ 
List of Files
- ReadMe.txt: Contains List of Files and description
- A_star.m: This is the main file that contains the algorithm. This needs to be executed to run the program.
- distance.m: This is a function that calculates the distance between 2 nodes.
- min_fn.m: This function takes the list QUEUE as one of its arguments and returns the node with the smallest cost function.
- index.m: This function returns the index of the location of a node in the list QUEUE.
- expand.m: This function takes a node and returns the expanded list of successors (child nodes), with the calculated fn values.
- insert: This function populates the list QUEUE with values that have been passed to it. 
%}
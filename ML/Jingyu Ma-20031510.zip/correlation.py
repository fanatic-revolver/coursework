import pandas as pd
from scipy.stats import spearmanr
from scipy import stats
import math
import numpy
import matplotlib.pyplot as plt

df = pd.read_excel('mean_value_predicted.xlsx') # read in the excel file
i = 0  # intilize the parameter to count the line in excel file
sumCHLA = 0.0 # this is the sum of CHLA
sumP = 0.0 # this is the sum of P
sumTEMP = 0.0 # this is the sum of Temprature

list_CHLA = [] # this list include every measurement of CHLA
list_TEMP = [] # this list include every corresponding Temprature
list_P = [] # this list include every corresponding P

# This is the function for finding the varience among a list
# def variance(data):
#  # Number of observations
#      n = len(data)
#      # Mean of the data
#      mean = sum(data) / n
#      # Square deviations
#      deviations = [(x - mean) ** 2 for x in data]
#      # Variance
#      variance = sum(deviations) / n
#      return variance

while i < df.shape[0]: # when the counter is less than the total line number in the excel
    dataCHLA = df.iloc[[i], [2]].values[0][0] # iloc function find the element in row[i] column[j] , if you print it you can see the line number , here we just take the value
    list_CHLA.append(dataCHLA) # append the extract CHLA to the data list
    sumCHLA += dataCHLA # add the data to the sum
    dataTEMP = df.iloc[[i], [3]].values[0][0] # same for temprature
    list_TEMP.append(dataTEMP)
    sumTEMP += dataTEMP
    dataP = df.iloc[[i], [4]].values[0][0] # same for P
    list_P.append(dataP)
    sumP += dataP
    i += 1     # counter plus one

average_CHLA = sumCHLA / (df.shape[0]) # calculate the average of CHLA

average_TEMP = sumTEMP / (df.shape[0]) # calculate the average TEMP

average_P = sumP / (df.shape[0])  # calculate the average P


sigma_XY = 0.0 # sum the deviation of X , Y from their mean

# please refer to the covarience fomula , here is just the implementation
for num in range(0, df.shape[0]):
    sigma_XY += (list_CHLA[num]-average_CHLA)*(list_TEMP[num]-average_TEMP)
CovarienceCT = sigma_XY/(df.shape[0]-1)

sigma_XY = 0.0

for num in range(0, df.shape[0]):
    sigma_XY += (list_CHLA[num]-average_CHLA)*(list_P[num]-average_P)
CovarienceCP = sigma_XY/(df.shape[0]-1)
sigma_XY = 0.0



print("协方差CHLA-TEMPRATURE：%f"%(CovarienceCT))
print("协方差CHLA-P：%f"%(CovarienceCP))

# varienceCHLA=variance(list_CHLA)       # Here is some code for the exact method for calculating the Persons's correlation , the number is slightly different from scipy
# varianceTEMP=variance(list_TEMP)
# varienceP=variance(list_P)
#
# CorrelationCT=CovarienceCT/(math.sqrt(varienceCHLA)*math.sqrt(varianceTEMP))
# CorrelationCP=CovarienceCP/(math.sqrt(varienceCHLA)*math.sqrt(varienceP))

CorrelationCT=stats.pearsonr(list_CHLA,list_TEMP)[0]    # pearson correlation , input is two lists
CorrelationCP=stats.pearsonr(list_CHLA,list_P)[0]

print("Pearson相关系数CT：%f"%(CorrelationCT))
print("Pearson相关系数CP：%f"%(CorrelationCP))

CorrelationCT=spearmanr(list_CHLA,list_TEMP)    # spearman correlation , input is two lists
CorrelationCP=spearmanr(list_CHLA,list_P)

print("Spearman相关系数CT：%f"%(CorrelationCT[0]))
print("Spearman相关系数CP：%f"%(CorrelationCP[0]))

TauCT, p_value =stats.kendalltau(list_CHLA,list_TEMP)  # kendall correlation , input is two lists
TauCP, p_value =stats.kendalltau(list_CHLA,list_P)

print("Kendall's tau相关系数CHLA-Temp：%f"%(TauCT))
print("Kendall's tau相关系数CHLA-P：%f"%(TauCP))

data_matrix = df.corr()                   # caculate the multiple correlation between CHLA to TEMP & P
R12 = data_matrix['CHLA （mg/L）']['Temp']
R13 = data_matrix['CHLA （mg/L）']['P']
R23 = data_matrix['Temp']['P']
R123 = math.sqrt((numpy.square(R12)+numpy.square(R13)-2*R12*R13*R23)/(1-numpy.square(R23)))

print("Multiple Correlation:%f" % R123)

plt.scatter(list_CHLA, list_TEMP)
plt.xlabel('CHLA (mg/L)')
plt.ylabel('TEMPERATURE(Centrigrade)')
plt.show()

plt.scatter(list_CHLA, list_P)
plt.xlabel('CHLA (mg/L)')
plt.ylabel('Total P (mg/L)')
plt.show()

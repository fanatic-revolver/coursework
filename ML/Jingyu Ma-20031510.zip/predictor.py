import pandas
from sklearn import linear_model
import matplotlib.pyplot as plt
df = pandas.read_csv("simplified_dataP.csv")

X = df[['Month', 'Depth','TEMP']]
y = df['P']

regr = linear_model.LinearRegression()
regr.fit(X, y)

# 预测月份为 6、深度为 6 ,温度为17.9的磷含量：

predictedP = regr.predict([[6, 6, 17.9]])


print(predictedP)



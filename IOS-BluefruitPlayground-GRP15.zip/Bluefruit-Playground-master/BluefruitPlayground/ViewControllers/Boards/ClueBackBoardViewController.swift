//
//  ClueBackBoardViewController.swift
//  BluefruitPlayground
//
//  Created by Antonio García on 07/03/2020.
//  Copyright © 2020 Adafruit. All rights reserved.
//

import UIKit

class ClueBackBoardViewController: NeopixelsBoardViewController {
    // Constants
    static let kIdentifier = "ClueBackBoardViewController"

    override func viewDidLoad() {
        super.viewDidLoad()

    }
}

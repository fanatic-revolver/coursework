//
//  CPBBoardViewController.swift
//  BluefruitPlayground
//
//  Created by Antonio García on 13/10/2019.
//  Copyright © 2019 Adafruit. All rights reserved.
//

import UIKit


class CPBBoardViewController: NeopixelsBoardViewController {
    // Constants
    static let kIdentifier = "CPBBoardViewController"

}

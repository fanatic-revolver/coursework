//
//  ClueFrontBoardViewController.swift
//  BluefruitPlayground
//
//  Created by Antonio García on 07/03/2020.
//  Copyright © 2020 Adafruit. All rights reserved.
//

import UIKit

class ClueFrontBoardViewController: UIViewController {
    // Constants
    static let kIdentifier = "ClueFrontBoardViewController"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}

-- 20031510 scyjm2 Jingyu Ma 
module Schelling
  ( Coord
  , AgentType (..)
  , Cell

  , step
  , moore
  , genNeighbours
  , isHappy
  
  ) where

import System.Random

-- type-definition of a coordinate in our world
type Coord = (Int, Int)

-- data definition for the agent types
data AgentType 
  = Red       -- ^ Red agent
  | Green     -- ^ Green agent
  | Blue      -- ^ Blue agent
  deriving Eq -- Needed to compare for equality, otherwise would need to implement by ourself

-- Type-definition of a Cell: it is just a coordinate and an optional AgentType.
-- Note: the agent type is optional and is Nothing in case the cell is empty.
type Cell = (Coord, Maybe AgentType)

-- Computes one step of the Schelling Segregation model. The algorithm works as:
--  1. mark all unhappy agents
--  2. move all unhappy agents to any random Emtpy cell
--  3. all happy agents stay at the same position
step :: [Cell]           -- ^ All cells of the world
     -> StdGen           -- ^ The random-number generator
     -> Double           -- ^ The ratio of equal neighbours an agent requires to be happy
     -> ([Cell], StdGen) -- ^ Result is the new list of cells and the updated random-number generator
step cs g ratio = (cs', g')
    where
        emptyCells = filter isEmpty cs
        agents = filter (not . isEmpty) cs
        happyAgents = filter (isHappy ratio cs) agents
        unhappyAgents = filter (not . isHappy ratio cs) agents
        (unhappyAgents', emptyCells', g') = foldr swapRand ([], emptyCells, g) unhappyAgents
        cs' = happyAgents ++ unhappyAgents' ++ emptyCells'
        
-- Tell if a cell is contains an agent
isEmpty :: Cell
    -> Bool    
isEmpty cell = (snd cell) == Nothing

-- Neighbors relatve coordinates, in clockwise order
moore :: [Coord]
moore=[(0,1),(1,1),(1,0),(1,-1),(0,-1),(-1,-1),(-1,0),(-1,1)]

-- Calculate cell's potential neighbours' absolute coordinates using moore list and cell's absolute coordinate
genNeighbours :: [Coord] -> Coord -> [Coord]
genNeighbours cs c = map addCoord cs
    where
        addCoord c' = (fst c + fst c', snd c + snd c')
        
-- Computes whether a cell is happy                        
isHappy :: Double
        -> [Cell]
        -> Cell
        -> Bool
isHappy ration cells c= (fromIntegral lnSAgs / fromIntegral lnAgs) > ration
    where
        --Neighbors
        nCs = filter (\cell-> elem (fst cell) (genNeighbours moore (fst c))) cells 
        -- Neighbors with agents
        nAgs = filter (not . isEmpty) nCs
        -- Agents have same type
        nSAgs = filter (\cell-> snd cell == snd c) nAgs
        lnAgs = length nCs
        lnSAgs = length nSAgs
        

swapRand :: Cell
        -> ([Cell], [Cell], StdGen)
        -> ([Cell], [Cell], StdGen)
swapRand cell s = (unhappyAgents', emptyCells', g')
    where
        (unhappyAgents, emptyCells, g) = s
        n = length emptyCells
        (r, g') = randomR (0, n-1) g
        emptyCell = emptyCells!!r
        unhappyAgents' = (fst emptyCell, snd cell):unhappyAgents
        emptyCells' = (fst cell, Nothing): filter (/=emptyCell) emptyCells
        
        
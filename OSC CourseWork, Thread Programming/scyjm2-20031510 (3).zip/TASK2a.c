#include <stdio.h>
#include <stdlib.h>
#include "coursework.h"
#include "linkedlist.h"

int main() {
	//Declare variables in which to store response and turnaround times
	long int responseTime[NUMBER_OF_PROCESSES];
	long int turnaroundTime[NUMBER_OF_PROCESSES];
	double averageResponseTime = 0;
	double averageTurnaroundTime = 0;
	
	//define vital elements of the linkedlist
	struct element * pHead = NULL;
	struct element * pTail = NULL;
	//generate all process
    for (int i=0;i<NUMBER_OF_PROCESSES;i++) {
        struct process * newProcess = generateProcess();
        addLast(newProcess, &pHead, &pTail);
    }
	responseTime[0] = 0;
	//run all process
    for (int i=0;i<NUMBER_OF_PROCESSES;i++) {
		struct process *oCurProcess = pHead->pData;

		runNonPreemptiveJob(pHead->pData, &(oCurProcess->oMostRecentTime),
			&(oCurProcess->oMostRecentTime));
		if(i<NUMBER_OF_PROCESSES-1) {
			responseTime[i+1] = getDifferenceInMilliSeconds(oCurProcess->oTimeCreated, oCurProcess->oMostRecentTime);
		}
		turnaroundTime[i] = getDifferenceInMilliSeconds(oCurProcess->oTimeCreated, oCurProcess->oMostRecentTime);
		averageResponseTime += (double) responseTime[i];
		averageTurnaroundTime += (double) turnaroundTime[i];

        struct process *oToFree = removeFirst(&pHead, &pTail);
		printf("Process Id = %d, Previous Burst Time = %d, New Burst Time = %d, Response Time = %d, Turn Around Time = %d \n",
				oCurProcess->iProcessId,oCurProcess->iPreviousBurstTime,oCurProcess->iRemainingBurstTime,
				responseTime[i],turnaroundTime[i]);
    }
	//analyse all response time and turnaround time
	//to give average times of the overall times
	averageResponseTime /= NUMBER_OF_PROCESSES;
	printf("Average response time = %lf\n", averageResponseTime);
	averageTurnaroundTime /= NUMBER_OF_PROCESSES;
	printf("Average turn around time = %lf\n", averageTurnaroundTime);

    return 0;
}

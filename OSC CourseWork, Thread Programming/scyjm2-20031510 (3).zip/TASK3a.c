#include <stdio.h>
#include <stdlib.h>
#include "coursework.h"
#include "linkedlist.h"


int main(){
//produce 5 processes and put it into a linked list in turn

int current_producer=0;
int current_consumer=0;
int consume_count=0;
int item_produce_count=0;
int buffer_count=0;
int thisResponseTime=0;
int totalResponseTime =0;
int thisTurnaroundTime =0;
int totalTurnaroundTime =0;
struct  timeval getcputime;
struct element * pHead = NULL;
struct element * pTail = NULL;



for(;;)
{
 

if(item_produce_count==100)
{
	if(buffer_count!=0)
	{
	  goto label;
	}
	else if(buffer_count==0)             //end exectution
    {
    break;
    }
	
}
 

 if(buffer_count<MAX_BUFFER_SIZE)   //produce
{
   if(current_producer==0)                          //if current producer is 0,use producer 0 to generate a process,change producer to 1
  {//add process to the linked list
   struct process* newProcess=generateProcess();
   item_produce_count++;
   printf("Producer=%d,Items Produced=%d,New Process ID=%d,Burst Time=%d\n",current_producer,item_produce_count,newProcess->iProcessId,newProcess->iInitialBurstTime);
   addLast(newProcess,&pHead,&pTail);
   buffer_count++;
   current_producer=1;
  }
  else if(current_producer==1)                     //if current producer is 1,use producer 1 to generate a process,change producer to 0
  {
  //add process to the linked list
   struct process* newProcess=generateProcess();
   item_produce_count++;
   addLast(newProcess,&pHead,&pTail);
   buffer_count++;
   printf("Producer=%d,Items Produced=%d,New Process ID=%d,Burst Time=%d\n",current_producer,item_produce_count,newProcess->iProcessId,newProcess->iInitialBurstTime);
   current_producer=0;
  } 
}

else if(buffer_count>=MAX_BUFFER_SIZE)   //consume
{
 label: if(current_consumer==0)                 //if current consumer is 0,use consumer 0 to generate a process,change producer to 1 
  {
   struct process * thisprocess=pHead->pData; 
   buffer_count--; 
   consume_count++;
   gettimeofday(&getcputime,NULL);
    thisResponseTime = getDifferenceInMilliSeconds(thisprocess->oTimeCreated, getcputime); 
   	runNonPreemptiveJob(pHead->pData, &(thisprocess->oMostRecentTime),&(thisprocess->oMostRecentTime));
   	thisTurnaroundTime = getDifferenceInMilliSeconds(thisprocess->oTimeCreated, thisprocess->oMostRecentTime);
   	struct process * oToFree=removeFirst(&pHead,&pTail);
   printf("Consumer = %d,Process Id = %d,Previous Burst Time = %d,New Burst Time = %d,Response Time = %d, Turn Around Time = %d\n",current_consumer,thisprocess->iProcessId,thisprocess->iInitialBurstTime,thisprocess->iRemainingBurstTime,thisResponseTime,thisTurnaroundTime);  
  
   totalTurnaroundTime +=thisTurnaroundTime ;
   totalResponseTime += thisResponseTime;
   current_consumer++;          
  }
  else if(current_consumer==1)               //if current consumer is 1,use consumer 1 to generate a process,change producer to 2
  {
   struct process * thisprocess=pHead->pData; 
   buffer_count--;
   consume_count++;
    gettimeofday(&getcputime,NULL);
     thisResponseTime = getDifferenceInMilliSeconds(thisprocess->oTimeCreated, getcputime); 
   runNonPreemptiveJob(pHead->pData, &(thisprocess->oMostRecentTime),&(thisprocess->oMostRecentTime));
   	thisTurnaroundTime = getDifferenceInMilliSeconds(thisprocess->oTimeCreated, thisprocess->oMostRecentTime);
   	struct process * oToFree=removeFirst(&pHead,&pTail);
   printf("Consumer = %d,Process Id = %d,Previous Burst Time = %d,New Burst Time = %d,Response Time = %d, Turn Around Time = %d\n",current_consumer,thisprocess->iProcessId,thisprocess->iInitialBurstTime,thisprocess->iRemainingBurstTime,thisResponseTime,thisTurnaroundTime);  
  
    totalTurnaroundTime +=thisTurnaroundTime ;
   totalResponseTime += thisResponseTime;
    current_consumer++;
  }
  else if(current_consumer==2)         //if current consumer is 2,consume with consumer 2,change consumer to 3
  {
   struct process * thisprocess=pHead->pData;  
   buffer_count--;
   consume_count++;
    gettimeofday(&getcputime,NULL);//get the time of this process's first time to get the cpu,Response=Time at which the process gets the CPU for the first time-Arrival time
     thisResponseTime = getDifferenceInMilliSeconds(thisprocess->oTimeCreated, getcputime); 
   runNonPreemptiveJob(pHead->pData, &(thisprocess->oMostRecentTime),&(thisprocess->oMostRecentTime));
   	thisTurnaroundTime = getDifferenceInMilliSeconds(thisprocess->oTimeCreated, thisprocess->oMostRecentTime);
   	struct process * oToFree=removeFirst(&pHead,&pTail);
   printf("Consumer = %d,Process Id = %d,Previous Burst Time = %d,New Burst Time = %d,Response Time = %d, Turn Around Time = %d\n",current_consumer,thisprocess->iProcessId,thisprocess->iInitialBurstTime,thisprocess->iRemainingBurstTime,thisResponseTime,thisTurnaroundTime);  
    totalTurnaroundTime +=thisTurnaroundTime ;
   totalResponseTime += thisResponseTime;
   current_consumer++;
  }
  else if(current_consumer==3)        //if current consumer is 3,consume with consumer 3,change consumer to 0
  {
  struct process * thisprocess=pHead->pData; 
   buffer_count--;
   consume_count++;
    gettimeofday(&getcputime,NULL);       //get the time of this process's first time to get the cpu,Response=Time at which the process gets the CPU for the first time-Arrival time
     thisResponseTime = getDifferenceInMilliSeconds(thisprocess->oTimeCreated, getcputime); 
   runNonPreemptiveJob(pHead->pData, &(thisprocess->oMostRecentTime),&(thisprocess->oMostRecentTime));
   	thisTurnaroundTime = getDifferenceInMilliSeconds(thisprocess->oTimeCreated, thisprocess->oMostRecentTime);
   	struct process * oToFree=removeFirst(&pHead,&pTail);
   printf("Consumer = %d,Process Id = %d,Previous Burst Time = %d,New Burst Time = %d,Response Time = %d, Turn Around Time = %d\n",current_consumer,thisprocess->iProcessId,thisprocess->iInitialBurstTime,thisprocess->iRemainingBurstTime,thisResponseTime,thisTurnaroundTime);  
    totalTurnaroundTime +=thisTurnaroundTime ;
   totalResponseTime += thisResponseTime;
   current_consumer=0;
  }

}
 
 
}
	//analyse all response time and turnaround time
	//to give average times of the overall times
	double averageResponseTime = totalResponseTime/consume_count;
	double averageTurnaroundTime = totalTurnaroundTime/consume_count;
	printf("Average response time = %lf\n", averageResponseTime);
	printf("Average turn around time = %lf\n",  averageTurnaroundTime);

return 0;

}

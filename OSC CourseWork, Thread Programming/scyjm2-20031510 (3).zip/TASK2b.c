#include <stdio.h>
#include <stdlib.h>
#include "coursework.h"
#include "linkedlist.h"

int main() {
	int completedProcesses = 0; //Set no of completed processes - complete when = NUMBER_OF_PROCESSES
	//define vital elements of the linkedlist
	struct element * pHead = NULL;
	struct element * pTail = NULL;
	int firstRun = 1;

	//Declare variables in which to store response and turnaround times
	long int responseTime[NUMBER_OF_PROCESSES];
	long int turnaroundTime[NUMBER_OF_PROCESSES];
	double averageResponseTime = 0;
	double averageTurnaroundTime = 0;
	
	printf("PROCESS LIST:\n");
	//generate all processes
	for (int i = 0; i < NUMBER_OF_PROCESSES; i++) {
		struct process * newProcess = generateProcess();
		addLast(newProcess, &pHead, &pTail);
		printf("         Process Id = %d, Initial Burst Time = %d, Remaining Burst Time = %d\n",
			   newProcess->iProcessId, newProcess->iInitialBurstTime, newProcess->iRemainingBurstTime);
	}
	printf("END\n");

	responseTime[0] = 0;
	do {
		struct element * currentElement = pHead; //Go back to beginning of the list

		for (int i = 0; i < NUMBER_OF_PROCESSES; i++) {
			struct process * oCurProcess = currentElement->pData;

			if (oCurProcess->iRemainingBurstTime > 0) {
				runPreemptiveJob(oCurProcess, &(oCurProcess->oMostRecentTime), &(oCurProcess->oMostRecentTime));
				printf("\nProcess Id = %d, Previous Burst Time = %d, Remaining Burst Time = %d",
					   oCurProcess->iProcessId, oCurProcess->iPreviousBurstTime, oCurProcess->iRemainingBurstTime);
				
				if (firstRun) {
					if (i < NUMBER_OF_PROCESSES - 1) {
						responseTime[i+1] = getDifferenceInMilliSeconds(oCurProcess->oTimeCreated, oCurProcess->oMostRecentTime);
					}
					averageResponseTime += (double) responseTime[i];
					printf(", Response Time = %d", responseTime[i]);
				}

				//Increment the count of completed processes if the process is complete
				if (oCurProcess->iRemainingBurstTime == 0) {
					completedProcesses++;
					turnaroundTime[i] = getDifferenceInMilliSeconds(oCurProcess->oTimeCreated, oCurProcess->oMostRecentTime);
					averageTurnaroundTime += (double) turnaroundTime[i];
					printf(", Turnaround Time = %d", turnaroundTime[i]);
				}
			}

			currentElement = currentElement->pNext; //Move onto the next element in the list for next loop
		}
		if (firstRun) {
			firstRun = 0;
		}
	} while (completedProcesses < NUMBER_OF_PROCESSES);

	averageResponseTime /= NUMBER_OF_PROCESSES;
	printf("\nAverage response time = %lf", averageResponseTime);
	averageTurnaroundTime /= NUMBER_OF_PROCESSES;
	printf("\nAverage turn around time = %lf\n", averageTurnaroundTime);
}

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#define SIZE_OF_MEMORY 24
#define SHARED_MEMORY_NAME "mjy"


int main()
{
  int shm_fd = shm_open(SHARED_MEMORY_NAME, O_RDWR | O_CREAT,0666);
  if(shm_fd==-1){
    printf("failed to open shared memory\n");
    exit(1);
  }
  if(ftruncate(shm_fd,SIZE_OF_MEMORY)==-1)
    {
      printf("failed to set size of memory\n");
    }

  int * i_ptr=mmap(NULL,SIZE_OF_MEMORY,PROT_READ|PROT_WRITE,MAP_SHARED,shm_fd,0);
  while(i_ptr[21]<=10)
    {
      if(i_ptr[21]==i_ptr[22])
	{
          i_ptr[i_ptr[21]*2-1]=i_ptr[23]*2;
          i_ptr[23]=i_ptr[i_ptr[21]*2-1];
         // printf("IN round %d,RandInt = %d,child process 1,\n",i_ptr[21],i_ptr[23]);
          i_ptr[21]=i_ptr[21]+1;
         }
    }
}

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>

#define max 20
#define min 1
#define SIZE_OF_MEMORY 24
#define SHARED_MEMORY_NAME "mjy"

int main()
{
  int RandInt;
  int status;
  srand(time(0));
  RandInt=rand()%(max-min)+min;
  printf("The RandInt =%d,created by the parent process\n",RandInt);

  int shm_fd=shm_open(SHARED_MEMORY_NAME, O_RDWR|O_CREAT,0666);
  if(shm_fd==-1){
    printf("failed to open shared memory\n");
    exit(1);
  }
  if(ftruncate(shm_fd,SIZE_OF_MEMORY)==-1)
    {
      printf("failed to open shared memory\n");
    }
  int *i_ptr=mmap(NULL,SIZE_OF_MEMORY, PROT_READ | PROT_WRITE,MAP_SHARED,shm_fd,0);
  i_ptr[0]=RandInt;
  i_ptr[21]=1;
  i_ptr[22]=1;
  i_ptr[23]=RandInt;
  int i;
  pid_t pid;
  for(i=0;i<2;i++)
    {
      pid=fork();
      if(pid==0)
      {
	if(i==0)
	 {
	   execl("./ChildP1","ChildP1",NULL);
           break;
         }
	else if(i==1)
	  {
            execl("./ChildP2","ChildP2",NULL);
	    break;
          }
      }

    }


if(pid>0)
  {
    waitpid(pid,&status,WUNTRACED);
  }
int g;
for(g=1;g<=10;g++)
{
 printf("IN round %d ,RandInt %d,child process 1,\n",g,i_ptr[(2*g-1)]);
 printf("IN round %d ,RandInt %d,child process 2,\n",g,i_ptr[2*g]);
}

return 0;
}

This file is empty please do a mark deduction.

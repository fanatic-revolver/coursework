<?php
include 'config.php';
if(isset($_POST["u_btn"])){
  $u_name=$_POST["u_name"];
  $u_email=$_POST["u_email"];
  $u_pass=$_POST["u_pass"];
  $u_passport=$_POST["u_passport"];
  $u_tel=$_POST["u_tel"];
  $u_fullname=$_POST["u_fullname"];

  if(empty($u_name)||empty($u_email)||empty($u_pass)||empty($u_pass)||empty($u_passport)||empty($u_fullname)){
  echo  " <font color=ffffff> Please input all data </font> ";
  }else{
    $insert=mysqli_query($conn,"INSERT INTO `users` (`u_name`, `u_email`, `u_pass`, `u_passport`, `u_tel`, `u_fullname`) VALUES ( '$u_name', '$u_email', '$u_pass', '$u_passport', '$u_tel', '$u_fullname')");
    echo  "<font color=ffffff> Success!</font> ";
  }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <meta charset="UTF-8">
    <title>Sunny Isle Register</title>
    <link rel="stylesheet" href="css/style1.css">
</head>
<style>
    input::-webkit-input-placeholder { /* WebKit, Blink, Edge */
        color:    white;
    }
    :-moz-placeholder { /* Mozilla Firefox 4 to 18 */
        color:    white;
    }
    ::-moz-placeholder { /* Mozilla Firefox 19+ */
        color:    white;
    }
    input:-ms-input-placeholder { /* Internet Explorer 10-11 */
        color:   white;
    }
    input::-ms-input-placeholder { /* Microsoft Edge */
        color:    white;
    }
</style>
<body>
<a href="login.php" style="color: white" class="pos"><i class="fas fa-sign-in-alt">Login</i></a>
<!--<a href="index.php" style="color: white" ><img src="images/home.png" class="pos_abs" width="20" height="20" align ="right"></a>-->
  <a href="index.php" style="color: white" class="pos_abs"><i class="fas fa-home">Home</i></a>
  
<form class="box" action="register.php" method="post">
    </br>
    </br>
    </br>
    <h1>Register</h1>
    <input type="text" style="color: white" name="u_fullname" placeholder="Real Name" required="required">
    <input type="text" style="color: white"name="u_name" placeholder="Username" required="required">
    <input type="text" style="color: white"name="u_passport" placeholder="Passport ID" required="required">
    <input type="text" style="color: white "name="u_tel" placeholder="telephone number" required="required">
    <input type="email" style="color: white"name="u_email" placeholder="Email" required="required">
    <input type="password"style="color: white" name="u_pass" placeholder="Password" required="required">
    <input type="password"style="color: white" name="confirm" placeholder="Confirm Password" required="required">
    <input type="submit" name="u_btn" value="Register">
</form>

</body>
</html>

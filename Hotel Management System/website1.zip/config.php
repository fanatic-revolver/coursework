<?php
$server= 'localhost';
$user='root';
$pass='';
$db='system';

$conn=mysqli_connect($server,$user,$pass) or die("error");
//try{
  //$conn=new PDO("mysql:host=localhost;dbname=test","root","");
  //$conn->setAttribute(PDO::ATTR_ERRMODE,
                      //PDO::ERRMODE_EXCEPTION);
    //echo"DE connect success!";
//}catch(PDOException $e){
  //echo"DB connect failed!"
//}

$selectdb = mysqli_select_db($conn,$db) or die("error");

if(isset($_COOKIE["login"])){
  $login=$_COOKIE["login"];
}else{
  $login=0;
}
?>

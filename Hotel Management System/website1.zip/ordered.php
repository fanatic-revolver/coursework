<?php
include 'config.php';
if($login==0){
echo "<meta http-equiv='refresh' content='0; url=login.php'>";
}else{
  $u_id=$_COOKIE['uid'];
  $getinfo = mysqli_query($conn,"SELECT * FROM users WHERE u_id =$u_id");
  $arr=mysqli_fetch_array($getinfo);
}
 $room_num=-1;
 $realname=$arr['u_fullname'];

?>

<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>User Order|Sunny Isle</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta tag Keywords -->

	<!-- Custom-Files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<!-- Font-Awesome-Icons-CSS -->
	<!-- //Custom-Files -->

	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Crimson+Text:400,400i,600,600i,700,700i" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Oxygen:300,400,700&amp;subset=latin-ext" rel="stylesheet">
	<!-- //Web-Fonts -->
  <style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #f0546A;
  color: white;
}
.button {
  display: inline-block;
  border-radius: 4px;
  background-color: #f0546A;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 16px;
  padding: 15px 52px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '»';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>
</head>

<body>
	<!-- main banner -->
	<div class="main-top" id="home">
		<!-- header -->
		<header>
			<div class="container-fluid">
				<div class="header d-md-flex justify-content-between align-items-center py-3 px-xl-5 px-lg-3 px-2">
					<!-- logo -->
					<div id="logo">
						<h1><a href="index.php">Sunny Isle</a></h1>
					</div>
					<!-- //logo -->
					<!-- nav -->
					<div class="nav_w3ls">
						<nav>
							<label for="drop" class="toggle">Menu</label>
							<input type="checkbox" id="drop" />
							<ul class="menu">
								<li><a href="index.php" class="active">Home</a></li>
								<li><a href="about.php">About Us</a></li>
                <li><a href="book.php">Book</a></li>
								<li>
									<!-- First Tier Drop Down -->
									<label for="drop-2" class="toggle toogle-2"><img  src="images/account-circle-line.png"width="30" height="30" align="left"> <span class="fa fa-angle-down" aria-hidden="true"></span>
									</label>
									<a href="#"><?php echo $arr['u_fullname'];?><img  src="images/account-circle-line.png"width="30" height="30" align="left"> <span class="fa fa-angle-down" aria-hidden="true"></span></a>
									<input type="checkbox" id="drop-2" />
									<ul>
                    <li><a href="ordered.php" class="drop-text">Order</a></li>
										<li><a href="logout.php" class="drop-text">Log Out</a></li>
									</ul>
								</li>
							</ul>
						</nav>
					</div>
					<!-- //nav -->
				</div>
			</div>
		</header>
		<!-- //header -->

		<!-- banner -->
		<div class="banner_w3lspvt-2">

		</div>
		<!-- //banner -->
	</div>
	<!-- //main banner -->

	<!-- page details -->
	<div class="breadcrumb-mobamu">
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="index.php">Home</a>
			</li>
			<li class="breadcrumb-item active" aria-current="page">Order Status</li>
		</ol>
	</div>
	<!-- //page details -->

	<!-- booking form -->
	<div class="register-w3 py-5">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="tittle text-center text-bl font-weight-bold">Your Order Status</h3>
			<p class="sub-tittle text-center mt-2 mb-sm-5 mb-4 pb-xl-3">Welcome, you can view all your orders here.</p>
			<div class="comment-top mt-5">
				<div class="comment-bottom mobamuinfo_mail_grid_right">






        <div align="center">
          <h2>Your Room Order</h2>
                   <table id="customers">
                          <tr><th>id</th><th>room</th><th>name</th><th>type</th><th>Start</th><th>End</th><th></th></tr>
                   <?php
                          $selectfdb=mysqli_query($conn,"SELECT * FROM `room order` WHERE `guest_name`='$realname'");
                          $row=mysqli_num_rows($selectfdb);
                          for($i=0;$i<$row;$i++){
                                          $sql_arr = mysqli_fetch_assoc($selectfdb);
                                          $id = $sql_arr['check_id'];
                                          $num = $sql_arr['room_num'];
                                          $guest = $sql_arr['guest_name'];
                                          if($sql_arr['type_id']==1){
                                              $type="Large Double";
                                          }
                                          elseif($sql_arr['type_id']==2){
                                            $type="Large Single";
                                          }
                                          elseif($sql_arr['type_id']==3){
                                            $type="Small Single";
                                          }else{
                                            $type="VIP Room";
                                          }
                                          $Start=$sql_arr['startdate'];
                                          $End=$sql_arr['lastdate'];
                                          echo "<div><tr><td>$id</td><td>$num</td><td>$guest</td><td>$type</td><td>$Start</td><td>$End</td><td><div align='center'> <form action='ordered.php' method='post'><button type='submit'  name='$i' value='$id'>Delete</button></form></div></td></tr></div>";
                                          if(isset($_POST["$i"])){
                                           mysqli_query($conn,"DELETE FROM `room order` WHERE `check_id`='$id'");
                                             echo "<meta http-equiv='refresh' content='0; url=ordered.php'>";
                                   }
                                          }




                         ?>

                            </table>
                          </div>


				</div>
			</div>
		</div>
	</div>
	<!-- //booking form -->

	<!-- footer -->
	<footer class="py-5">
		<div class="container pt-xl-4">
			<div class="row footer-top">
				<div class="col-lg-4 col-md-6 footer-grid_section_1its">
					<h2 class="logo-2 mb-lg-4 mb-3">
						<a href="index.php" class="text-uppercase text-wh">Sunny Isle</a>
					</h2>
					<!-- Map -->
					<div class="map-fo">
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3606.0282329139377!2d121.56147991411612!3d29.802723263584635!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x344d7c404423a4b5%3A0x793fcb6ce55375c2!2z5a-n5rOi6Ku-5LiB5ryi5aSn5a24!5e0!3m2!1szh-TW!2s!4v1556956671807!5m2!1szh-TW!2s" width="300" height="200" frameborder="0" style="border:0" allowfullscreen></iframe>
					</div>
					<!-- //Map -->
				</div>
				<div class="col-lg-2 col-md-6 footer-grid_section_1its mt-md-0 mt-4">
					<h3 class="footer-title text-uppercase text-wh mb-lg-4 mb-3">Links</h3>
					<ul class="list-unstyled">
						<li class="mb-3">
							<a href="index.php">Home</a>
						</li>
						<li class="mb-3">
							<a href="about.php">About Us</a>
						</li>
						<li class="mb-3">
							<a href="#services">Services</a>
						</li>
					</ul>
				</div>
				<div class="col-lg-3 col-md-6 footer-grid_section_1its mt-lg-0 mt-4">
					<h3 class="footer-title text-uppercase text-wh mb-lg-4 mb-3">Contact Info</h3>
					<div class="contact-info">
						<div class="footer-style-w3ls mb-4">
							<h4 class="text-li mb-2">Phone</h4>
							<p>+86 13916493742</p>
						</div>
						<div class="footer-style-w3ls mb-4">
							<h4 class="text-li mb-2">Email </h4>
							<p><a href="mailto:scyjm2@nottingham.edu.cn">scyjm2@nottingham.edu.cn</a></p>
						</div>
						<div class="footer-style-w3ls mb-4">
							<h4 class="text-li mb-2">Location</h4>
							<p>East Region, Lukewarm Kingdom</p>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 footer-grid_section_1its mt-lg-0 mt-4">
					<!-- social icons -->
					<div class="mobamuinfo_social_icons">
						<h3 class="footer-title text-uppercase text-wh mb-lg-4 mb-3">Social Info</h3>
						<p>Please feel free to find us in the following social media,we are looking forward to your comments.</br>Your anticipation is our motivation.</br>We serve,we dream.</p>
						<h4 class="sub-con-fo text-li my-4">Catch on Social</h4>
						<ul class="mobamuits_social_list list-unstyled">
							<li class="w3_mobamu_facebook">
								<a href="https://www.facebook.com/profile.php?id=100027424511544">
									<span class="fa fa-facebook-f"></span>
								</a>
							</li>
							<li class="w3_mobamu_twitter">
								<a href="https://www.linkedin.com/in/靖誉-马-644954161">
									<span class="fa fa-linkedin-square"></span>
								</a>
							</li>
							<li class="w3_mobamu_wechat">
								<a href="#">
									<span class="fa fa-weixin"></span>
								</a>
							</li>
							<li class="w3_mobamu_qq">
								<a href="#">
									<span class="fa fa-qq" ></span>
								</a>
							</li>
						</ul>
					</div>
					<!-- social icons -->
				</div>
			</div>
		</div>
	</footer>
	<!-- //footer -->
	<!-- copyright -->
	<div class="cpy-right text-center py-3">
		<p>© 2019 Sunny Isle. All rights reserved | Design by
			<a href="https://www.facebook.com/profile.php?id=100027424511544"> John</a>
		</p>
	</div>
	<!-- //copyright -->

	<!-- move top icon -->
	<a href="#home" class="move-top text-center"></a>
	<!-- //move top icon -->


</body>

</html>

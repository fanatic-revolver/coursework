package view;



import java.io.File;

import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
/**
 * Pacman class is responsible for the creation of pacman 
 * @author Jingyu Ma
 *
 */
public class Pacman extends Circle {

    public Pacman(double x, double y) {
    	
        File f=new File("src/view/GIFPacman.gif");
        String pathoffile=f.getAbsolutePath();
        Image im = new Image( "file:///"+pathoffile,false);
        this.setCenterX(x);
        this.setCenterY(y);
        this.setRadius(25);
        this.setFill(new ImagePattern(im));
        
    }
}

package view;



import javafx.animation.AnimationTimer;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

import java.io.File;
import java.io.IOException;
import java.util.Random;

/**
 * This class response for all the things related to Ghosts
 * @author Jingyu Ma
 *
 */
public class Ghost extends Rectangle implements Runnable {
	private static final File f1=new File("src/view/ghost1.png");
    private static final String pathoffile1=f1.getAbsolutePath();
    private static final  String ghost1URL = "file:///"+pathoffile1;
	Image ghost1 = new Image(ghost1URL);
	
	private static final File f2=new File("src/view/ghost2.png");
    private static final String pathoffile2=f2.getAbsolutePath();
    private static final  String ghost2URL = "file:///"+pathoffile2;
	Image ghost2 = new Image(ghost2URL);
	
	private static final File f3=new File("src/view/ghost3.png");
    private static final String pathoffile3=f3.getAbsolutePath();
    private static final  String ghost3URL = "file:///"+pathoffile3;
	Image ghost3 = new Image(ghost3URL);
	
	private static final File f4=new File("src/view/ghost4.png");
    private static final String pathoffile4=f4.getAbsolutePath();
    private static final  String ghost4URL = "file:///"+pathoffile4;
	Image ghost4 = new Image(ghost4URL);
	
	private static final File f5=new File("src/view/ghost5.png");
    private static final String pathoffile5=f5.getAbsolutePath();
    private static final  String ghost5URL = "file:///"+pathoffile5;
	Image ghost5 = new Image(ghost5URL);
	
	

    String direction;
    GameManager gameManager;
    Maze maze;
    AnimationTimer animation;
    int timesWalked;
    
/**
 * Constructor of the ghost
 * @param x             spawn X
 * @param y             spawn Y
 * @param color         ghost's color
 * @param maze          current maze
 * @param gameManager   current game manager
 */
    public Ghost(double x, double y, Color color, Maze maze, GameManager gameManager) {
        this.setX(x);
        this.setY(y);
        this.maze = maze;
        this.gameManager = gameManager;
        this.setHeight(50);
        this.setWidth(50);
        if(color==Color.SPRINGGREEN) {
        this.setFill(new ImagePattern(ghost1, 0, 0, 1, 1, true));
        }
        else if(color==Color.DODGERBLUE) {
            this.setFill(new ImagePattern(ghost2, 0, 0, 1, 1, true));
            }
        else if(color==Color.DEEPPINK) {
            this.setFill(new ImagePattern(ghost3, 0, 0, 1, 1, true));
            }
        else if(color==Color.GOLDENROD) {
            this.setFill(new ImagePattern(ghost4, 0, 0, 1, 1, true));
            }
        else if(color==Color.PURPLE) {
            this.setFill(new ImagePattern(ghost5, 0, 0, 1, 1, true));
            }
        this.timesWalked = 0;
        this.direction = "down";
        this.createAnimation();
    }

    /**
     * Gets a random direction 
     * @param exclude1
     * @param exclude2
     * @return
     */
    private String getRandomDirection(String exclude1, String exclude2) {
        String[] directions = {"left", "right", "up", "down"};
        int rnd = new Random().nextInt(directions.length);
        while (directions[rnd].equals(exclude1) || directions[rnd].equals(exclude2)) {
            rnd = new Random().nextInt(directions.length);
        }
        return directions[rnd];
    }

    /**
     * Gets a random boolean
     * @return
     */
    private boolean getRandomBoolean() {
        Random rand = new Random();
        return rand.nextBoolean();
    }

    /**
     * Gets the animation for the ghost
     * @return animation the continue update animation of ghost
     */
    public AnimationTimer getAnimation() {
        return animation;
    }

    /**
     *
     * @param direction
     */
    private void checkIftheresPathToGo(String direction) {
        double rightEdge, leftEdge, topEdge, bottomEdge;
        switch (direction) {
            case "down":
                leftEdge = getX() - 10;
                bottomEdge = getY() + getHeight() + 15;
                rightEdge = getX() + getWidth() + 10;
                if (!maze.hasObstacle(leftEdge, rightEdge, bottomEdge - 1, bottomEdge)) {
                    this.direction = direction;
                }
                break;
            case "up":
                leftEdge = getX() - 10;
                rightEdge = getX() + getWidth() + 10;
                topEdge = getY() - 15;
                if (!maze.hasObstacle(leftEdge, rightEdge, topEdge - 1, topEdge)) {
                    this.direction = direction;
                }
                break;
            case "left":
                leftEdge = getX() - 15;
                bottomEdge = getY() + getHeight() + 10;
                topEdge = getY() - 10;
                if (!maze.hasObstacle(leftEdge - 1, leftEdge, topEdge, bottomEdge)) {
                    this.direction = direction;
                }
                break;
            case "right":
                bottomEdge = getY() + getHeight() + 10;
                rightEdge = getX() + getWidth() + 15;
                topEdge = getY() - 10;
                if (!maze.hasObstacle(rightEdge - 1, rightEdge, topEdge, bottomEdge)) {
                    this.direction = direction;
                }
                break;
        }
    }

    /**
     *
     * @param whereToGo
     * @param whereToChangeTo
     * @param leftEdge
     * @param topEdge
     * @param rightEdge
     * @param bottomEdge
     * @param padding
     */
    private void moveUntilYouCant(String whereToGo, String whereToChangeTo, double leftEdge, double topEdge, double rightEdge, double bottomEdge, double padding) {
        double step = 5;
        switch (whereToGo) {
            case "left":
            	this.setScaleX(-1);
                if (!maze.isTouching(leftEdge, topEdge, padding)) {
                    setX(leftEdge - step);
                } else {
                    while (maze.isTouching(getX(), getY(), padding)) {
                        setX(getX() + 1);
                    }
                    direction = whereToChangeTo;
                }
                break;
            case "right":
            	this.setScaleX(1);
                if (!maze.isTouching(rightEdge, topEdge, padding)) {
                    setX(leftEdge + step);
                } else {
                    while (maze.isTouching(getX() + getWidth(), getY(), padding)) {
                        setX(getX() - 1);
                    }
                    direction = whereToChangeTo;
                }
                break;
            case "up":
            	this.setScaleX(1);
                if (!maze.isTouching(leftEdge, topEdge, padding)) {
                    setY(topEdge - step);
                } else {
                    while (maze.isTouching(getX(), getY(), padding)) {
                        setY(getY() + 1);
                    }
                    direction = "left";
                }
                break;
            case "down":
            	this.setScaleX(-1);
                if (!maze.isTouching(leftEdge, bottomEdge, padding)) {
                    setY(topEdge + step);
                } else {
                    while (maze.isTouching(getX(), getY() + getHeight(), padding)) {
                        setY(getY() - 1);
                    }
                    direction = "right";
                }
                break;
        }

    }

    /**
     * Creates an animation of the ghost
     */
    public void createAnimation() {

        this.animation = new AnimationTimer()
        {
            public void handle(long currentNanoTime)
            {
                gameManager.checkGhostCoalition();
                double leftEdge = getX();
                double topEdge = getY();
                double rightEdge = getX() + getWidth();
                double bottomEdge = getY() + getHeight();
                double padding = 12;
                timesWalked++;
                int walkAtLeast = 4;
                switch (direction) {
                    case "left":
                        moveUntilYouCant("left", "down", leftEdge, topEdge, rightEdge, bottomEdge, padding);
                        if (timesWalked > walkAtLeast) {
                            checkIftheresPathToGo(getRandomDirection("left", "right"));
                            timesWalked = 0;
                        }
                        break;
                    case "right":
                        moveUntilYouCant("right", "up", leftEdge, topEdge, rightEdge, bottomEdge, padding);
                        if (timesWalked > walkAtLeast) {
                            checkIftheresPathToGo(getRandomDirection("left", "right"));
                             timesWalked = 0;
                        }
                        break;
                    case "up":
                        moveUntilYouCant("up", "left", leftEdge, topEdge, rightEdge, bottomEdge, padding);
                        if (timesWalked > walkAtLeast) {
                            checkIftheresPathToGo(getRandomDirection("up", "down"));
                            timesWalked = 0;
                        }
                        break;
                    case "down":
                        moveUntilYouCant("down", "right", leftEdge, topEdge, rightEdge, bottomEdge, padding);
                        if (timesWalked > walkAtLeast) {
                            checkIftheresPathToGo(getRandomDirection("up", "down"));
                            timesWalked = 0;
                        }
                        break;
                }
            }
        };
    }

    @Override
    public void run() {
        this.animation.start();
    }
}

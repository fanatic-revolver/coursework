package view;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.SHIP;
import model.ShipPicker;
import model.InfoLabel;
import model.PacmanButton;
import model.PacmanSubscene;
import view.GameManager;
/**
 * View Manager is responsible for scene transition and the menu
 * @author Jingyu Ma
 *
 */
public class ViewManager {
   private static final int height = 768;
private static final int width = 1024;
private AnchorPane mainPane;
   private Scene mainScene;
   private Stage mainStage;
   public Stage theStage;
   private PacmanSubscene creditsSubscene;
   private PacmanSubscene helpSubscene;
   private PacmanSubscene scoreSubscene;
   private PacmanSubscene chooseSubscene;
   private final static int MENU_BUTTON_START_X=100;
   private final static int MENU_BUTTON_START_Y=150;
   
   private PacmanSubscene sceneToHide;
   
   List<PacmanButton> menuButtons;
   List<ShipPicker> shipList;
   private SHIP choosenShip;
   
   /**
    * ViewManager contructor
    */
   public ViewManager() {
	   menuButtons=new ArrayList<>();
	   mainPane=new AnchorPane();
	   mainScene=new Scene(mainPane,width,height);
	   mainStage=new Stage();
	   mainStage.setScene(mainScene);
	   createSubScenes();
	   createBackground();
	   createButtons();
	   createLogo();
//	   PacmanSubscene subScene=new PacmanSubscene();
//	   subScene.setLayoutX(200);
//	   subScene.setLayoutY(100);
//	   mainPane.getChildren().add(subScene);
   }
   
   /**
    * Move the subscene into the view
    * @param subScene
    */
   private void showSubScene(PacmanSubscene subScene) {
	   if(sceneToHide!=null) {
		   sceneToHide.moveSubScene();
	   }
	   
	   subScene.moveSubScene();
	   sceneToHide=subScene;
   }
   
   
   /**
    * Open the game with the given color
    * @param choosenCOLOR
    */
   private void rungame(SHIP choosenCOLOR) {
	   mainStage.close();
	   Stage theStage=new Stage();
	       Group root = new Group();
	       Scene theScene = new Scene( root);
	       if( (int)(1+Math.random()*8)==1){
	    	   theScene.setFill(Color.WHITE);
	       }
	       else if( (int)(1+Math.random()*8)==2){
	    	   theScene.setFill(Color.BLACK);
	       }
	       else if( (int)(1+Math.random()*8)==3){
	    	   theScene.setFill(Color.CYAN);
	       }
	       else if( (int)(1+Math.random()*8)==4){
	    	   theScene.setFill(Color.GREY);
	       }
	       else if( (int)(1+Math.random()*8)==5){
	    	   theScene.setFill(Color.TOMATO);
	       }
	       else if( (int)(1+Math.random()*8)==6){
	    	   theScene.setFill(Color.RED);
	       }
	       else if( (int)(1+Math.random()*8)==7){
	    	   theScene.setFill(Color.CHARTREUSE);
	       }
	       else if( (int)(1+Math.random()*8)==8){
	    	   theScene.setFill(Color.ORANGE);
	       }
	       
	       theStage.setScene( theScene );
	  Canvas canvas = new Canvas( 1920, 1080 );
	  root.getChildren().add( canvas );
	  root.getChildren().add(createButtonToMenu(theStage));


	GameManager gameManager = new GameManager(root);

	gameManager.drawBoard();
	

	theScene.addEventHandler(KeyEvent.KEY_PRESSED, event -> gameManager.movePacman(event));
	theScene.addEventHandler(KeyEvent.KEY_RELEASED, event -> gameManager.stopPacman(event));
	theScene.addEventHandler(KeyEvent.KEY_PRESSED, event -> gameManager.restartGame(event));
	theStage.setTitle("Pacman");
	
	theStage.show();
   }
   
   
   /**
    * Run the default game
    */
   private void rungame() {
	   mainStage.close();
	    theStage=new Stage();
	       Group root = new Group();
	       Scene theScene = new Scene( root);
	       theStage.setScene( theScene );
	  Canvas canvas = new Canvas( 1225, 600);
	  root.getChildren().add( canvas );

	  root.getChildren().add(createButtonToMenu(theStage));
	GameManager gameManager = new GameManager(root);

	gameManager.drawBoard();
	

	theScene.addEventHandler(KeyEvent.KEY_PRESSED, event -> gameManager.movePacman(event));
	theScene.addEventHandler(KeyEvent.KEY_RELEASED, event -> gameManager.stopPacman(event));
	theScene.addEventHandler(KeyEvent.KEY_PRESSED, event -> gameManager.restartGame(event));
	theStage.setTitle("Pacman");
	
	theStage.show();
   }
   
   /**
    * Create the panels on the menu
    */
   private void createSubScenes(){
	  // creditsSubscene=new PacmanSubscene();
	  // mainPane.getChildren().add(creditsSubscene);
	   
	   createcreditsSubscene();
	   
	   helpSubscene=new PacmanSubscene();
	   mainPane.getChildren().add(helpSubscene);
	   
	   scoreSubscene=new PacmanSubscene();
	   mainPane.getChildren().add(scoreSubscene);
	   
	  
	   
	   
	   
	   createCOLORSubScenes();
   }
   
   /**
    * Create a panel with a choosing option
    */
   private void createCOLORSubScenes() {
	// TODO Auto-generated method stub
	   chooseSubscene=new PacmanSubscene(); 
	   mainPane.getChildren().add(chooseSubscene);
	   InfoLabel chooseColorLabel=new InfoLabel("CHOOSE YOUR COLOR");
	   chooseColorLabel.setLayoutX(80);
	   chooseColorLabel.setLayoutY(25);
	   chooseSubscene.getPane().getChildren().add(chooseColorLabel);
	   chooseSubscene.getPane().getChildren().add(createColorsToChoose());
	   chooseSubscene.getPane().getChildren().add(createButtonToStart());
}
   
   /**
    * Create credits subscene
    */
   private void createcreditsSubscene() {
		// TODO Auto-generated method stub
	   creditsSubscene=new PacmanSubscene(); 
		   mainPane.getChildren().add(creditsSubscene);
		   InfoLabel chooseColorLabel=new InfoLabel("This is the origianl game");
		   chooseColorLabel.setLayoutX(80);
		   chooseColorLabel.setLayoutY(25);
		   creditsSubscene.getPane().getChildren().add(chooseColorLabel);
		   creditsSubscene.getPane().getChildren().add(createButtonToStartOrg());
	}
   
   
   /**
    * Create the color selection part in the color choosing subscene
    * @return these UI element
    */
   private HBox createColorsToChoose() {
	   HBox box=new HBox();
	   box.setSpacing(20);
	   shipList=new ArrayList<>();
	   for(SHIP color:SHIP.values()) {
		   ShipPicker shipToPick=new ShipPicker(color);
		   shipList.add(shipToPick);
		   box.getChildren().add(shipToPick);
		   shipToPick.setOnMouseClicked(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				for(ShipPicker color:shipList) {
					color.setIsCircleChoosen(false);
				}
				shipToPick.setIsCircleChoosen(true);
				choosenShip=shipToPick.getColor();
			}
		   });
		   }
	   box.setLayoutX(300-(118*2));
	   box.setLayoutY(100);
	   return box;
	   }
   
   
   /**
    * Create a start button to start the game
    * @return startButton
    */
  private PacmanButton createButtonToStart() {
	  PacmanButton startButton=new PacmanButton("START");
	  startButton.setLayoutX(350);
	  startButton.setLayoutY(300);
	   startButton.setOnAction(new EventHandler<ActionEvent>(){

				@Override
				public void handle(ActionEvent event) {
					// TODO Auto-generated method stub
			  
       			  rungame(choosenShip);
			  
			  
				}
				   
			   });
	  return startButton;
  }
  
  /**
   * Create a button in the game back to the menu
   * @param theStage           takes the current stage and close it 
   * @return startButton  the button to start the game
   */
  public PacmanButton createButtonToMenu(Stage theStage) {
	  PacmanButton startButton=new PacmanButton("BACK");
	  startButton.setLayoutX(1050);
	  startButton.setLayoutY(650);
	   startButton.setOnAction(new EventHandler<ActionEvent>(){

				@Override
				public void handle(ActionEvent event) {
					// TODO Auto-generated method stub
					theStage.close();
					menuButtons=new ArrayList<>();
					   mainPane=new AnchorPane();
					   mainScene=new Scene(mainPane,width,height);
					   mainStage=new Stage();
					   mainStage.setScene(mainScene);
					   createSubScenes();
					   createBackground();
					   createButtons();
					   createLogo();
					   mainStage.show();
				}
				   
			   });
	  return startButton;
  }
  
  
  
  private PacmanButton createButtonToStartOrg() {
	  PacmanButton startButton=new PacmanButton("START");
	  startButton.setLayoutX(350);
	  startButton.setLayoutY(300);
	   startButton.setOnAction(new EventHandler<ActionEvent>(){

				@Override
				public void handle(ActionEvent event) {
					// TODO Auto-generated method stub
			  
       			  rungame();
			  
			  
				}
				   
			   });
	  return startButton;
  }
   
/**
 * Get the mainStage
 * @return mainstage The stage that contains the menu
 */
public Stage getMainStage() {
	   return mainStage;
   }
   
/**
 * create all the buttons on the left side
 */
   public void createButtons() {
	   createPLAYButton();
	   createScoresButton();
	   createHelpButton();
	   createCreditsButton();
	   createExitButton();
   }
   
   /**
    * create a play button
    */
   public void createPLAYButton() {
	   PacmanButton PLAYButton = new PacmanButton("PLAY");
	   addMenuButton(PLAYButton);
	   PLAYButton.setOnAction(new EventHandler<ActionEvent>(){

				@Override
				public void handle(ActionEvent event) {
					// TODO Auto-generated method stub
				showSubScene(chooseSubscene);
//				  rungame();
				}
				   
			   });
	  
   }
   
   /**
    * Create a background
    */
   public void createBackground() {
	   Image backgroundImage=new Image("view/resources/background.jpg",256,256,false,true);
	   BackgroundImage background=new BackgroundImage(backgroundImage,BackgroundRepeat.REPEAT,BackgroundRepeat.REPEAT,BackgroundPosition.DEFAULT,null);
	   mainPane.setBackground(new Background(background));
   }
   
   /**
    * Create a menu button to the menu
    * @param button takes a pre-made button
    */
   public void addMenuButton(PacmanButton button) {
	   button.setLayoutX(MENU_BUTTON_START_X);
	   button.setLayoutY(MENU_BUTTON_START_Y+menuButtons.size()*100);
	   menuButtons.add(button);
	   mainPane.getChildren().add(button);
   }
   
   /**
    * create a exit button to exit game
    */
   private void createExitButton() {
	   PacmanButton exitButton=new PacmanButton("EXIT");
	   addMenuButton(exitButton);
	   exitButton.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
			mainStage.close();
			}
			   
		   });
   }
   
   /**
    * create a credits button
    */
   public void createCreditsButton() {
	   PacmanButton CreditsButton = new PacmanButton("Credits");
	   addMenuButton(CreditsButton);
	   CreditsButton.setOnAction(new EventHandler<ActionEvent>(){

		@Override
		public void handle(ActionEvent event) {
			// TODO Auto-generated method stub
			showSubScene(creditsSubscene);
		}
		   
	   });
   }
   
   
   /**
    * create a help button
    */
   public void createHelpButton() {
	   PacmanButton HelpButton = new PacmanButton("Help");
	   addMenuButton(HelpButton);
	   HelpButton.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				showSubScene(helpSubscene);
			}
			   
		   });
   }
   
   
   
   /**
    * create a score button
    */
   public void createScoresButton() {
	   PacmanButton ScoresButton = new PacmanButton("Scores");
	   addMenuButton(ScoresButton);
	   ScoresButton.setOnAction(new EventHandler<ActionEvent>(){

			@Override
			public void handle(ActionEvent event) {
				// TODO Auto-generated method stub
				showSubScene(scoreSubscene);
			}
			   
		   });
   }
   
   
   
   /**
    * create a logo on the top corner with special effects
    */
   public void createLogo() {
	   ImageView logo=new ImageView("view/resources/pacmanpng-1024x316.png");
	   logo.setLayoutX(180);
	   logo.setLayoutY(-80);
	   logo.setScaleX(0.4);
	   logo.setScaleY(0.4);
	   
	   logo.setOnMouseEntered(new EventHandler<MouseEvent>() {
		   @Override
		   public void handle(MouseEvent event) {
			   logo.setEffect(new DropShadow());
		   }
	   
	   });
	   
	   logo.setOnMouseExited(new EventHandler<MouseEvent>() {

		@Override
		public void handle(MouseEvent arg0) {
			// TODO Auto-generated method stub
			logo.setEffect(null);
		}
	   });
	   
	   mainPane.getChildren().add(logo);
   }
   
   
   
  
   
   
   
}

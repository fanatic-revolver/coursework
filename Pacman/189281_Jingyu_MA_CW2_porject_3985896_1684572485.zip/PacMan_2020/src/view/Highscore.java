package view;



/**
 * This method is used to create a buy order priority queue to store Score
 * @author Jingyu Ma
 *
 */

public class Highscore implements Comparable<Highscore> {
  public Integer score;
  public String ID;

  public Integer getscore() {
      return score;
  }

  public void setscore(Integer score) {
      this.score = score;
  }

  
  public void setID(String ID) {
      this.ID = ID;
  }

  public String getID() {
      return ID;
  }

 

  public Highscore(){}

  public Highscore(Integer score,String ID){
      this.score=score;
      this.setID(ID);
  }

  @Override
  public String toString() {
      return score.toString();

  }

  public boolean equals(Highscore other){
      return this.getscore()==other.getscore();
  }

  public int compareTo(Highscore other) {
      if(this.equals(other))
          return 0;
      else if(getscore()<other.getscore())
          return 1;
      else
          return -1;
  }
  
}


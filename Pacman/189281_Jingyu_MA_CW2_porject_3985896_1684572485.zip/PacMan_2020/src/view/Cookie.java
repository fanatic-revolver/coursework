package view;



import java.io.File;

import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;

/**
 * First read in all the pictures and add them to the cookie,cookie is a coin-like object 
 * 
 * @author Jingyu Ma
 *
 */
public class Cookie extends Circle {
	 //File f=new File("src/view/RPi.png");
    // String pathoffile=f.getAbsolutePath();
    // Image im = new Image( "file:///"+pathoffile,false);
	
	 File f=new File("src/view/orange.png");
     String pathoffile=f.getAbsolutePath();
     Image orange = new Image( "file:///"+pathoffile,false);
     File f1=new File("src/view/cherry.jpg");
     String pathoffile1=f1.getAbsolutePath();
     Image cherry = new Image( "file:///"+pathoffile1,false);
   //  File f2=new File("src/view/RPi.png");
 //   String pathoffile2=f2.getAbsolutePath();
  //  Image raspberry = new Image( "file:///"+pathoffile2,true);
     File f3=new File("src/view/starwberry.jpg");
     String pathoffile3=f3.getAbsolutePath();
     Image starwberry = new Image( "file:///"+pathoffile3,false);

    private int value;

    /**
     * The basic unit of  a cookie,the initializer
     * @param x centerX of the cookie
     * @param y centerY of the cookie
     */
    public Cookie(double x, double y) {
        this.value = 5;
        this.setCenterX(x);
        this.setCenterY(y);
        this.setRadius(12.5);
        this.setFill(Color.SADDLEBROWN);
    }
    
    
    /**
     * Another type of cookie,if you specify the type it can become different such as cherry
     * @param x  centerX of the cookie
     * @param y  centerY of the cookie
     * @param type  the cookie type of the cookie
     */
    public Cookie(double x, double y,String type) {
        this.value = 10;
        this.setCenterX(x);
        this.setCenterY(y);
        this.setRadius(23);
        if(type=="orange") {
        this.setFill(new ImagePattern(orange)); 
        this.value=500;
    }
        else if(type=="cherry"){
        	 this.setFill(new ImagePattern(cherry));
        	 this.value=100;
        }
        else if(type=="starwberry"){
       	 this.setFill(new ImagePattern(starwberry));  
       	this.value=300;
       }
       
        else {
        	this.setFill(Color.CRIMSON);
        }
        
    }

    
    /**
     * Get the value of the cookie
     * @return value the value of cookie
     */
    public int getValue() {
        return value;
    }

    /**
     * Hide the cookie
     */
    public void hide() {
        this.setVisible(false);
    }

    
    /**
     * Show the cookie
     */
    public void show() {
        this.setVisible(true);
    }

}
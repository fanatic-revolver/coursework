package model;

import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
/**
 * This ship picker class will generate the checkbox in the panel
 * @author 		Jingyu Ma
 *
 */
public class ShipPicker extends VBox {
   private ImageView circleImage;
   private ImageView ghostImage;
   
   private String circleNotChoosen="view/resources/colorchooser/grey_circle.png";
   private String circleChoosen="view/resources/colorchooser/yellow_boxTick.png";
   
   public SHIP color;
   
   private boolean isCircleChoosen;
   
   /**
    * Add all the checkbox to the panel
    * @param color the current coloe the player choose
    */
   public ShipPicker(SHIP color) {
	   circleImage=new ImageView(circleNotChoosen);
	 //  ghostImage=new ImageView(color.getUrl());
	   isCircleChoosen=false;
	   this.setAlignment(Pos.CENTER);
	   this.setSpacing(20);
	   this.getChildren().add(circleImage);
	  // this.getChildren().add(ghostImage);
   }
   
   /**
    * Get the current color
    * @return the current color
    */
   public SHIP getColor() {
	   return color;
   }
   
   
   
   /**
    * Judge if you have click the button
    * @return A boolean isCircleChoosen  This parameter indicates if the the user click on the selection
    */
   public boolean getIsCircleChoosen() {
	   return isCircleChoosen;
   }
   
   
   
   /**
    * If the circle is choosen switch the image 
    * @param isCircleChoosen   check if the user click on the selection
    */
   public void setIsCircleChoosen(boolean isCircleChoosen) {
	   this.isCircleChoosen=isCircleChoosen;
	   String imageToSet=this.isCircleChoosen ? circleChoosen:circleNotChoosen;
	   circleImage.setImage(new Image(imageToSet));
   }
}

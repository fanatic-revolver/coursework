package model;

public enum SHIP {

	 GREY("view/resources/colorchooser/grey.png"),
	 BLACK("view/resources/colorchooser/black.jpg"),
	 WHITE("view/resources/colorchooser/white.png"),
	 ORANGE("view/resources/colorchooser/orange.jpg"),
	 RED(""),
	 BLUE(""),
	 PINK(""),
	 GREEN("");
	 
	 String urlCOLOR;
	
	 /**
	  * Set the url color
	  * @param urlCOLOR
	  */
	 private SHIP(String urlCOLOR) {
		 this.urlCOLOR=urlCOLOR;
	 }
	 
	 /**
	  * Get the current url(path) 
	  * @return the url
	  */
	 public String getUrl() {
		 return this.urlCOLOR;
	 }
	 
	 /**
	  * Get the current name
	  * @return current name
	  */
	 public String getname() {
		 return this.name();
	 }
	
}

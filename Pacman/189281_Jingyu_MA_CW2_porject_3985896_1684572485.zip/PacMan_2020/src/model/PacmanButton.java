package model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Font;

public class PacmanButton extends Button {
	
	private final String FONT_PATH="src/model/resources/xirod.ttf";
	private final String BUTTON_PRESSED_STYLE="-fx-background-color:transparent;-fx-background-image:url('/model/resources/yellow_button03.png');";
	private final String BUTTON_FREE_STYLE="-fx-background-color:transparent;-fx-background-image:url('/model/resources/yellow_button02.png');";
	
	/**
	 * initialize the button with 190x49,set the picture of button
	 * @param text the text to put inside the button
	 */
	public PacmanButton(String text) {
		setText(text);
		setButtonFont();
		setPrefWidth(190);
		setPrefHeight(49);
		setStyle(BUTTON_FREE_STYLE);
		initializeButtonListener();
	}
	
	
	/**
	 * This method is used to set the font
	 */
	private void setButtonFont() {
		try {
			setFont(Font.loadFont(new FileInputStream(FONT_PATH), 23));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			setFont(Font.font("Verdana", 23));
		}
	}
	
	/**
	 * This method is used to change the button style when it is pressed
	 */
	private void setButtonPressedStyle() {
		setStyle(BUTTON_PRESSED_STYLE);
		setPrefHeight(45);
		setLayoutY(getLayoutY()+4);
	}
	
	/**
	 * This method is used to change the button style when it is released
	 */
	private void setButtonReleasedStyle() {
		setStyle(BUTTON_FREE_STYLE);
		setPrefHeight(49);
		setLayoutY(getLayoutY()-4);
	}
	
	
	/**
	 * This listener will listen for the click event,it will handle what happen at mouse enter,release,exited
	 */
	private void initializeButtonListener() {
		
		setOnMousePressed(new EventHandler<MouseEvent>(){
			@Override
			public void handle(MouseEvent event) {
				if(event.getButton().equals(MouseButton.PRIMARY)) {
					setButtonPressedStyle();
					}
				}
	      });
		
		   setOnMouseReleased(new EventHandler<MouseEvent>(){
			   @Override
			   public void handle(MouseEvent event) {
				   if(event.getButton().equals(MouseButton.PRIMARY)) {
					   setButtonReleasedStyle();
					 }
				 }
	        });
		   
		   
		   setOnMouseEntered(new EventHandler<MouseEvent>(){
			   @Override
			   public void handle(MouseEvent event) {
				   setEffect(new DropShadow());
				 }
	        });
		   
		   
		   setOnMouseExited(new EventHandler<MouseEvent>(){
			   @Override
			   public void handle(MouseEvent event) {
				   setEffect(null);
				 }
	        });
		   
		   
		   
		   
     }
	
    	
	
        
	
	
	
	
	
	
	
	
	
}
